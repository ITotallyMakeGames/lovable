# H5345 Gjd 45 Gj

make a game that's built around an infinite clicker game where there's leaderboards that track your currency. and the currency is sushi. the leaderboards should track total sushi. and you must sign in with google with your name.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://h5345-gjd-45-gj.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/ba2d60ad-de7a-47be-acf5-47725bb8c42f).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
