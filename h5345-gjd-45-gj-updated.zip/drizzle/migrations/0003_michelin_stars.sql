ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS michelin_stars integer NOT NULL DEFAULT 0;
CREATE OR REPLACE FUNCTION public.guard_profile_update()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.total_sushi < OLD.total_sushi THEN NEW.total_sushi := OLD.total_sushi; END IF;
  IF NEW.michelin_stars < OLD.michelin_stars THEN NEW.michelin_stars := OLD.michelin_stars; END IF;
  NEW.updated_at := now();
  RETURN NEW;
END; $$;