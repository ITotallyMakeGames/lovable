CREATE TABLE public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  display_name text NOT NULL DEFAULT '',
  avatar_url text,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 280),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.chat_messages TO anon;
GRANT SELECT, INSERT ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Chat is public" ON public.chat_messages FOR SELECT USING (true);
CREATE POLICY "Users post as themselves" ON public.chat_messages FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.fill_chat_author()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT p.display_name, p.avatar_url INTO NEW.display_name, NEW.avatar_url
  FROM public.profiles p WHERE p.id = NEW.user_id;
  NEW.display_name := COALESCE(NEW.display_name, 'Sushi Chef');
  NEW.created_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER chat_fill_author BEFORE INSERT ON public.chat_messages
FOR EACH ROW EXECUTE FUNCTION public.fill_chat_author();
CREATE INDEX chat_messages_created_idx ON public.chat_messages (created_at DESC);
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;