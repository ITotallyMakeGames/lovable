ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS sps double precision NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS profiles_sps_idx ON public.profiles (sps DESC);
CREATE POLICY "Avatar images are public" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
CREATE POLICY "Users upload own avatar" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Users update own avatar" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);