import { useEffect, useRef, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

type Msg = { id: string; user_id: string; display_name: string; avatar_url: string | null; body: string; created_at: string };
const PAGE = 50;

export function Chat({ user }: { user: User | null }) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [more, setMore] = useState(true);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const stick = useRef(true);

  useEffect(() => {
    supabase
      .from("chat_messages")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(PAGE)
      .then(({ data }) => {
        setMsgs((data ?? []).reverse());
        setMore((data?.length ?? 0) === PAGE);
      });
    const ch = supabase
      .channel(`chat-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, (p) => {
        const m = p.new as Msg;
        setMsgs((ms) => (ms.some((x) => x.id === m.id) ? ms : [...ms, m]));
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  useEffect(() => {
    if (stick.current && box.current) box.current.scrollTop = box.current.scrollHeight;
  }, [msgs]);

  const loadOlder = async () => {
    const first = msgs[0];
    if (!first) return;
    const el = box.current;
    const prevH = el?.scrollHeight ?? 0;
    const { data } = await supabase
      .from("chat_messages")
      .select("*")
      .lt("created_at", first.created_at)
      .order("created_at", { ascending: false })
      .limit(PAGE);
    stick.current = false;
    setMsgs((ms) => [...(data ?? []).reverse(), ...ms]);
    setMore((data?.length ?? 0) === PAGE);
    requestAnimationFrame(() => {
      if (el) el.scrollTop = el.scrollHeight - prevH;
    });
  };

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const body = text.trim();
    if (!body || !user || sending) return;
    setSending(true);
    stick.current = true;
    const { data, error } = await supabase.from("chat_messages").insert({ body, user_id: user.id }).select().single();
    setSending(false);
    if (!error) {
      setText("");
      if (data) setMsgs((ms) => (ms.some((x) => x.id === data.id) ? ms : [...ms, data]));
    }
  };

  return (
    <section className="flex flex-col rounded-2xl border-2 bg-card shadow-block">
      <h2 className="border-b-2 px-4 py-2 font-display text-lg">💬 Live chat</h2>
      <div
        ref={box}
        onScroll={(e) => {
          const t = e.currentTarget;
          stick.current = t.scrollHeight - t.scrollTop - t.clientHeight < 40;
        }}
        className="h-80 space-y-3 overflow-y-auto p-3"
      >
        {more && msgs.length > 0 && (
          <button onClick={loadOlder} className="mx-auto block rounded-full border-2 px-3 py-1 text-xs font-bold hover:bg-secondary">
            Load older messages
          </button>
        )}
        {msgs.length === 0 && <p className="text-center text-sm text-muted-foreground">No messages yet. Say hi!</p>}
        {msgs.map((m) => {
          const mine = m.user_id === user?.id;
          return (
            <div key={m.id} className={`flex gap-2 ${mine ? "flex-row-reverse" : ""}`}>
              <Avatar url={m.avatar_url} className="h-8 w-8 shrink-0" />
              <div className={`max-w-[75%] ${mine ? "text-right" : ""}`}>
                <p className="text-xs font-bold text-muted-foreground">
                  {m.display_name}{" "}
                  <span className="font-normal opacity-70">
                    {new Date(m.created_at).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                  </span>
                </p>
                <p
                  className={`inline-block whitespace-pre-wrap break-words rounded-xl border-2 px-3 py-1.5 text-left text-sm ${
                    mine ? "bg-primary text-primary-foreground" : "bg-background"
                  }`}
                >
                  {m.body}
                </p>
              </div>
            </div>
          );
        })}
      </div>
      {user ? (
        <form onSubmit={send} className="flex gap-2 border-t-2 p-2">
          <input
            value={text}
            onChange={(e) => setText(e.target.value.slice(0, 280))}
            placeholder="Say something to everyone…"
            aria-label="Chat message"
            className="min-w-0 flex-1 rounded-full border-2 bg-background px-3 py-1.5 text-sm outline-none focus:border-primary"
          />
          <button disabled={!text.trim() || sending} className="rounded-full border-2 bg-primary px-4 text-sm font-bold text-primary-foreground disabled:opacity-50">
            Send
          </button>
        </form>
      ) : (
        <p className="border-t-2 p-3 text-center text-xs text-muted-foreground">Sign in to chat.</p>
      )}
    </section>
  );
}

export function Avatar({ url, className = "" }: { url: string | null | undefined; className?: string }) {
  return url ? (
    <img src={url} alt="" referrerPolicy="no-referrer" className={`rounded-full border-2 object-cover ${className}`} />
  ) : (
    <span className={`block rounded-full border-2 bg-primary ${className}`} />
  );
}

// Shrinks a picked image into a small square JPEG so it can be stored directly on the profile.
export function imageToAvatar(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const s = 128;
      const c = document.createElement("canvas");
      c.width = c.height = s;
      const side = Math.min(img.width, img.height);
      c.getContext("2d")!.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, s, s);
      URL.revokeObjectURL(img.src);
      resolve(c.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}
