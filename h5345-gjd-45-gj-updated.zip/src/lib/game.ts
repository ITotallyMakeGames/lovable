export type Upgrade = {
  id: string;
  name: string;
  emoji: string;
  baseCost: number;
  perSecond: number;
  perClick: number;
};

// Each tier costs ~11-13x the previous and pays back in a similar, gently rising time,
// so the next upgrade is always roughly a minute or two of play away.
export const UPGRADES: Upgrade[] = [
  { id: "chopsticks", name: "Golden Chopsticks", emoji: "🥢", baseCost: 15, perSecond: 0, perClick: 1 },
  { id: "apprentice", name: "Apprentice Chef", emoji: "👨‍🍳", baseCost: 60, perSecond: 2, perClick: 0 },
  { id: "rice", name: "Rice Cooker", emoji: "🍚", baseCost: 350, perSecond: 8, perClick: 0 },
  { id: "belt", name: "Conveyor Belt", emoji: "🎢", baseCost: 2_000, perSecond: 32, perClick: 0 },
  { id: "boat", name: "Fishing Boat", emoji: "🚤", baseCost: 12_000, perSecond: 140, perClick: 0 },
  { id: "master", name: "Sushi Master", emoji: "🥷", baseCost: 75_000, perSecond: 650, perClick: 10 },
  { id: "restaurant", name: "Omakase Bar", emoji: "🏮", baseCost: 450_000, perSecond: 3_200, perClick: 0 },
  { id: "factory", name: "Maki Factory", emoji: "🏭", baseCost: 3_000_000, perSecond: 18_000, perClick: 0 },
  { id: "island", name: "Sushi Island", emoji: "🏝️", baseCost: 22_000_000, perSecond: 110_000, perClick: 0 },
  { id: "galaxy", name: "Wasabi Galaxy", emoji: "🌌", baseCost: 160_000_000, perSecond: 700_000, perClick: 1_500 },
  { id: "tuna", name: "Tuna Auction House", emoji: "🐟", baseCost: 1_200_000_000, perSecond: 5_000_000, perClick: 0 },
  { id: "shrine", name: "Omakase Shrine", emoji: "⛩️", baseCost: 9_000_000_000, perSecond: 35_000_000, perClick: 0 },
  { id: "dragon", name: "Golden Dragon Roll", emoji: "🐉", baseCost: 70_000_000_000, perSecond: 250_000_000, perClick: 50_000 },
  { id: "kraken", name: "Kraken Fishery", emoji: "🐙", baseCost: 550_000_000_000, perSecond: 1_800_000_000, perClick: 0 },
  { id: "moon", name: "Moon Rice Fields", emoji: "🌕", baseCost: 4_000_000_000_000, perSecond: 12_000_000_000, perClick: 0 },
];

export type Owned = Record<string, number>;

// Prices rise steadily per purchase, keeping early upgrades approachable while
// preventing one cheap upgrade from carrying the whole run.
export const UPGRADE_COST_GROWTH = 1.18;
export const costOf = (u: Upgrade, owned: number) =>
  Math.ceil(u.baseCost * Math.pow(UPGRADE_COST_GROWTH, owned));

export const perSecond = (owned: Owned) =>
  UPGRADES.reduce((s, u) => s + u.perSecond * (owned[u.id] ?? 0), 0);

export const perClick = (owned: Owned) =>
  1 + UPGRADES.reduce((s, u) => s + u.perClick * (owned[u.id] ?? 0), 0);

// Rebirth: every 1,000,000 sushi held trades for 1 Michelin Star; each star = +1% profit.
export const SUSHI_PER_STAR = 1_000_000;
export const starsFor = (sushi: number) => Math.floor(sushi / SUSHI_PER_STAR);
export const starMultiplier = (stars: number) => 1 + stars * 0.01;

// Offline earnings: paid for time away, capped at 24 hours.
export const OFFLINE_CAP_SECONDS = 24 * 60 * 60;
export const offlineEarnings = (sps: number, secondsAway: number) =>
  Math.max(0, sps) * Math.min(Math.max(0, secondsAway), OFFLINE_CAP_SECONDS);

export function fmtDuration(sec: number): string {
  const s = Math.floor(sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

const SUFFIX = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"];
export function fmt(n: number): string {
  if (!isFinite(n)) return "∞";
  if (n < 1000) return n < 10 && n % 1 !== 0 ? n.toFixed(1) : Math.floor(n).toLocaleString();
  const tier = Math.min(Math.floor(Math.log10(n) / 3), SUFFIX.length - 1);
  return (n / Math.pow(1000, tier)).toFixed(2) + SUFFIX[tier];
}
