import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

type Chain = {
  select: () => Chain;
  order: (key: string) => Chain;
  limit: () => Chain;
  then: (onFulfilled: (v: unknown) => unknown) => Promise<unknown>;
};

// Record which column each board asks the database to rank by, without a live backend.
const { orders, supabaseMock } = vi.hoisted(() => {
  const orders: string[] = [];
  const makeChain = (): Chain => {
    const chain = {} as Chain;
    chain.select = () => chain;
    chain.order = (key: string) => {
      orders.push(key);
      return chain;
    };
    chain.limit = () => chain;
    chain.then = (onFulfilled) => Promise.resolve({ data: [], error: null }).then(onFulfilled);
    return chain;
  };
  return { orders, supabaseMock: { from: () => makeChain() } };
});

vi.mock("@/integrations/supabase/client", () => ({ supabase: supabaseMock }));
vi.mock("@/integrations/lovable", () => ({ lovable: { auth: { signInWithOAuth: () => {} } } }));

import { Leaderboards } from "@/routes/index";

function renderBoards() {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={queryClient}>
      <Leaderboards userId="chef-1" />
    </QueryClientProvider>,
  );
}

afterEach(cleanup);

describe("Leaderboards", () => {
  it("opens on the all-time board and switches to ranking sushi held right now", async () => {
    renderBoards();

    await waitFor(() => expect(orders).toEqual(["total_sushi"]));

    fireEvent.click(screen.getByRole("tab", { name: "Current" }));

    await waitFor(() => expect(orders).toEqual(["total_sushi", "sushi"]));
  });
});
