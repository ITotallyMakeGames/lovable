import { describe, expect, it } from "vitest";
import { costOf, UPGRADES, offlineEarnings, starMultiplier, starsFor } from "@/lib/game";

describe("rebirth", () => {
  it("trades 1 million sushi for 1 star", () => {
    expect(starsFor(1_000_000)).toBe(1);
    expect(starsFor(999_999)).toBe(0);
  });
  it("10 million sushi gives 10 stars", () => {
    expect(starsFor(10_000_000)).toBe(10);
  });
  it("each star adds +1% profit", () => {
    expect(starMultiplier(10)).toBeCloseTo(1.1);
  });
  it("turns all full millions held into rebirth percentage points", () => {
    expect(starsFor(2_000_000)).toBe(2);
    expect(starsFor(2_999_999)).toBe(2);
  });
  it("upgrade prices rise with each purchase", () => {
    const firstUpgrade = UPGRADES[0];
    expect(costOf(firstUpgrade, 0)).toBe(firstUpgrade.baseCost);
    expect(costOf(firstUpgrade, 1)).toBeGreaterThan(costOf(firstUpgrade, 0));
  });
});

describe("offline earnings", () => {
  it("pays sps times seconds away, capped at 24h", () => {
    expect(offlineEarnings(10, 60)).toBe(600);
    expect(offlineEarnings(1, 48 * 3600)).toBe(24 * 3600);
  });
});
