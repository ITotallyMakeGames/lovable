import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useRef, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import sushiImg from "@/assets/sushi.png";
import {
  UPGRADES,
  SUSHI_PER_STAR,
  costOf,
  fmt,
  offlineEarnings,
  perClick,
  perSecond,
  starMultiplier,
  starsFor,
  type Owned,
} from "@/lib/game";
import { Avatar, Chat, imageToAvatar } from "@/components/Chat";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sushi Clicker — Roll your way to the top" },
      { name: "description", content: "An infinite sushi clicker. Tap, upgrade, and climb the global leaderboard for total sushi." },
      { property: "og:title", content: "Sushi Clicker — Roll your way to the top" },
      { property: "og:description", content: "Tap sushi, hire chefs, and climb the global total-sushi leaderboard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function useUser() {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user ?? null);
      setReady(true);
    });
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user ?? null);
      setReady(true);
    });
    return () => data.subscription.unsubscribe();
  }, []);
  return { user, ready };
}

function Index() {
  const { user, ready } = useUser();
  return (
    <div className="min-h-screen">
      <header className="border-b-2 border-border bg-nori text-nori-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <h1 className="font-display text-xl tracking-wide">寿司 SUSHI CLICKER</h1>
          {user && (
            <button
              onClick={() => supabase.auth.signOut()}
              className="rounded-full border-2 border-nori-foreground px-4 py-1 text-sm font-bold hover:bg-nori-foreground hover:text-nori"
            >
              Sign out
            </button>
          )}
        </div>
      </header>
      <main className="mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-[1fr_340px]">
        {!ready ? (
          <div className="py-24 text-center text-muted-foreground">Warming up the rice…</div>
        ) : user ? (
          <Game user={user} />
        ) : (
          <SignIn />
        )}
        <div className="space-y-6">
          <Leaderboards userId={user?.id} />
          <Chat user={user} />
        </div>
      </main>
    </div>
  );
}

function SignIn() {
  const [err, setErr] = useState<string | null>(null);
  const go = async () => {
    setErr(null);
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) setErr("Sign-in didn't work. Please try again.");
  };
  return (
    <section className="relative flex flex-col items-center justify-center overflow-hidden rounded-2xl border-2 bg-card p-10 text-center shadow-block">
      <div className="pointer-events-none absolute inset-0 bg-sun" />
      <img src={sushiImg} alt="Salmon nigiri" width={816} height={816} className="relative w-56 drop-shadow-xl" />
      <h2 className="relative mt-4 font-display text-4xl">Roll forever.</h2>
      <p className="relative mt-2 max-w-sm text-muted-foreground">
        Tap sushi, hire chefs, build an empire — and race everyone on the total sushi leaderboard.
      </p>
      <button
        onClick={go}
        className="relative mt-6 rounded-full border-2 bg-primary px-6 py-3 font-bold text-primary-foreground shadow-block transition-transform active:translate-x-1 active:translate-y-1 active:shadow-none"
      >
        Sign in with Google
      </button>
      <p className="relative mt-3 text-xs text-muted-foreground">Your Google name appears on the leaderboard.</p>
      {err && <p className="relative mt-2 text-sm text-destructive">{err}</p>}
    </section>
  );
}

type Pop = { id: number; x: number; y: number; v: number };

function Game({ user }: { user: User }) {
  const qc = useQueryClient();
  const [loaded, setLoaded] = useState(false);
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [sushi, setSushi] = useState(0);
  const [total, setTotal] = useState(0);
  const [owned, setOwned] = useState<Owned>({});
  const [stars, setStars] = useState(0);
  const [away, setAway] = useState<{ seconds: number; amount: number } | null>(null);
  const [pops, setPops] = useState<Pop[]>([]);
  const [squish, setSquish] = useState(false);
  const state = useRef({ sushi: 0, total: 0, owned: {} as Owned, stars: 0, dirty: false });
  state.current = { ...state.current, sushi, total, owned, stars };

  useEffect(() => {
    supabase
      .from("profiles")
      .select("display_name,avatar_url,sushi,total_sushi,upgrades,michelin_stars,updated_at")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          const up = (data.upgrades as Owned) ?? {};
          setName(data.display_name);
          setAvatar(data.avatar_url);
          setSushi(data.sushi);
          setTotal(data.total_sushi);
          setOwned(up);
          setStars(data.michelin_stars);
          const seconds = (Date.now() - new Date(data.updated_at).getTime()) / 1000;
          const amount = offlineEarnings(perSecond(up) * starMultiplier(data.michelin_stars), seconds);
          if (seconds >= 60 && amount >= 1) setAway({ seconds, amount });
        }
        setLoaded(true);
      });
  }, [user.id]);

  const save = useCallback(async () => {
    if (!state.current.dirty) return;
    state.current.dirty = false;
    const { sushi, total, owned, stars } = state.current;
    await supabase
      .from("profiles")
      .update({
        sushi,
        total_sushi: total,
        upgrades: owned,
        michelin_stars: stars,
        sps: perSecond(owned) * starMultiplier(stars),
      })
      .eq("id", user.id);
    qc.invalidateQueries({ queryKey: ["leaderboard"] });
  }, [user.id, qc]);

  const fileRef = useRef<HTMLInputElement>(null);
  const changeAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f || !f.type.startsWith("image/")) return;
    const url = await imageToAvatar(f);
    const { error } = await supabase.from("profiles").update({ avatar_url: url }).eq("id", user.id);
    if (!error) {
      setAvatar(url);
      qc.invalidateQueries({ queryKey: ["leaderboard"] });
    }
  };

  const mult = starMultiplier(stars);
  const cps = perSecond(owned) * mult;
  const cpc = perClick(owned) * mult;
  const claimable = starsFor(sushi);

  const collectOffline = () => {
    if (!away) return;
    setSushi((s) => s + away.amount);
    setTotal((t) => t + away.amount);
    state.current.dirty = true;
    setAway(null);
    setTimeout(save, 0);
  };

  const rebirth = () => {
    if (claimable < 1) return;
    const nextStars = stars + claimable;
    const gainedPercent = claimable;
    if (!window.confirm(
      `Rebirth now for +${gainedPercent}% sushi income? Your current sushi and upgrades will reset, but your lifetime total and existing rebirth bonus will stay.`
    )) return;

    // Keep lifetime total for the leaderboard. Everything in the current run resets.
    state.current = { ...state.current, sushi: 0, owned: {}, stars: nextStars, dirty: true };
    setSushi(0);
    setOwned({});
    setStars(nextStars);
    void save();
  };

  useEffect(() => {
    if (!loaded) return;
    const tick = setInterval(() => {
      const gain = (perSecond(state.current.owned) * starMultiplier(state.current.stars)) / 10;
      if (gain > 0) {
        setSushi((s) => s + gain);
        setTotal((t) => t + gain);
        state.current.dirty = true;
      }
    }, 100);
    const saver = setInterval(save, 5000);
    const onHide = () => save();
    window.addEventListener("beforeunload", onHide);
    return () => {
      clearInterval(tick);
      clearInterval(saver);
      window.removeEventListener("beforeunload", onHide);
      save();
    };
  }, [loaded, save]);

  const click = (e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    setSushi((s) => s + cpc);
    setTotal((t) => t + cpc);
    state.current.dirty = true;
    setSquish(true);
    setTimeout(() => setSquish(false), 80);
    const p = { id: Date.now() + Math.random(), x: e.clientX - rect.left, y: e.clientY - rect.top, v: cpc };
    setPops((ps) => [...ps.slice(-15), p]);
    setTimeout(() => setPops((ps) => ps.filter((q) => q.id !== p.id)), 900);
  };

  const buy = (id: string) => {
    const u = UPGRADES.find((x) => x.id === id)!;
    const c = costOf(u, owned[id] ?? 0);
    if (sushi < c) return;
    setSushi((s) => s - c);
    setOwned((o) => ({ ...o, [id]: (o[id] ?? 0) + 1 }));
    state.current.dirty = true;
  };

  if (!loaded) return <div className="py-24 text-center text-muted-foreground">Loading your kitchen…</div>;

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <section className="relative flex flex-col items-center overflow-hidden rounded-2xl border-2 bg-card p-6 shadow-block">
        <div className="pointer-events-none absolute inset-0 bg-sun" />
        <button
          onClick={() => fileRef.current?.click()}
          title="Change profile picture"
          className="group relative mb-1 rounded-full"
        >
          <Avatar url={avatar} className="h-14 w-14" />
          <span className="absolute -bottom-1 -right-1 rounded-full border-2 bg-background px-1 text-xs">✏️</span>
        </button>
        <input ref={fileRef} type="file" accept="image/*" hidden onChange={changeAvatar} aria-label="Upload profile picture" />
        <p className="relative text-sm font-bold text-muted-foreground">Chef {name}</p>
        <p className="relative font-display text-5xl text-primary">{fmt(sushi)}</p>
        <p className="relative text-sm font-bold">sushi</p>
        <p className="relative mt-1 text-xs text-muted-foreground">
          {fmt(cps)} / sec · {fmt(cpc)} / tap · {fmt(total)} lifetime total
        </p>
        <div className="relative mt-4 w-full rounded-xl border-2 border-primary/30 bg-background/90 p-3 text-center">
          <p className="font-display text-lg">⭐ Rebirth Kitchen</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Rebirth bonus: +{stars}% sushi income ({stars} star{stars === 1 ? "" : "s"})
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Need {fmt(SUSHI_PER_STAR)} sushi for each +1%. You currently qualify for +{claimable}%.
          </p>
          <button
            onClick={rebirth}
            disabled={claimable < 1}
            className="mt-3 w-full rounded-full border-2 bg-primary px-4 py-2 text-sm font-bold text-primary-foreground shadow-block transition enabled:hover:brightness-105 enabled:active:translate-y-0.5 enabled:active:shadow-none disabled:cursor-not-allowed disabled:opacity-40"
          >
            {claimable > 0 ? `Rebirth for +${claimable}% income` : `Need ${fmt(SUSHI_PER_STAR - sushi)} more sushi`}
          </button>
          <p className="mt-2 text-[11px] text-muted-foreground">
            Resets current sushi and all upgrades. Your lifetime total and rebirth bonuses stay.
          </p>
        </div>
        <button
          onClick={click}
          aria-label="Make sushi"
          className="relative mt-6 select-none rounded-full outline-none"
        >
          <img
            src={sushiImg}
            alt=""
            width={816}
            height={816}
            draggable={false}
            className={`w-64 drop-shadow-2xl transition-transform duration-75 hover:scale-105 ${squish ? "scale-90" : ""}`}
          />
          {pops.map((p) => (
            <span
              key={p.id}
              className="pointer-events-none absolute animate-float-up font-display text-2xl text-accent"
              style={{ left: p.x, top: p.y }}
            >
              +{fmt(p.v)}
            </span>
          ))}
        </button>
      </section>

      <section className="rounded-2xl border-2 bg-card p-4 shadow-block">
        <h2 className="mb-3 font-display text-lg">Kitchen Shop</h2>
        <ul className="space-y-2">
          {UPGRADES.map((u) => {
            const n = owned[u.id] ?? 0;
            const c = costOf(u, n);
            const can = sushi >= c;
            return (
              <li key={u.id}>
                <button
                  onClick={() => buy(u.id)}
                  disabled={!can}
                  className="flex w-full items-center gap-3 rounded-xl border-2 bg-background p-2 text-left shadow-block-sm transition enabled:hover:bg-secondary enabled:active:translate-x-0.5 enabled:active:translate-y-0.5 enabled:active:shadow-none disabled:opacity-45"
                >
                  <span className="text-2xl">{u.emoji}</span>
                  <span className="flex-1">
                    <span className="block text-sm font-bold">{u.name}</span>
                    <span className="block text-xs text-muted-foreground">
                      {u.perSecond > 0 && `+${fmt(u.perSecond)}/s `}
                      {u.perClick > 0 && `+${fmt(u.perClick)}/tap`}
                    </span>
                  </span>
                  <span className="text-right">
                    <span className="block text-sm font-bold text-primary">🍣 {fmt(c)}</span>
                    <span className="block text-xs text-muted-foreground">owned {n}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}

type SortKey = "total_sushi" | "sushi" | "sps";

const BOARDS: { key: SortKey; tab: string; title: string; hint: string }[] = [
  { key: "total_sushi", tab: "Total", title: "🏆 Total sushi", hint: "Ranked by total sushi ever made" },
  { key: "sushi", tab: "Current", title: "🍣 Current sushi", hint: "Ranked by sushi held right now" },
  { key: "sps", tab: "Per sec", title: "⚡ Sushi per second", hint: "Ranked by sushi made every second" },
];

export function Leaderboards({ userId }: { userId: string | undefined }) {
  const [active, setActive] = useState<SortKey>("total_sushi");
  const board = BOARDS.find((b) => b.key === active)!;
  return (
    <aside className="h-fit rounded-2xl border-2 bg-nori p-4 text-nori-foreground shadow-block">
      <div
        role="tablist"
        aria-label="Leaderboards"
        className="mb-3 grid grid-cols-3 gap-1 rounded-full border-2 border-nori-foreground/25 p-1"
      >
        {BOARDS.map((b) => (
          <button
            key={b.key}
            role="tab"
            aria-selected={b.key === active}
            onClick={() => setActive(b.key)}
            className={`rounded-full px-2 py-1 text-xs font-bold transition ${
              b.key === active ? "bg-primary text-primary-foreground" : "opacity-60 hover:opacity-100"
            }`}
          >
            {b.tab}
          </button>
        ))}
      </div>
      <h2 className="font-display text-lg">{board.title}</h2>
      <p className="mb-3 text-xs opacity-70">{board.hint}</p>
      <Board userId={userId} sortBy={active} />
    </aside>
  );
}

function Board({ userId, sortBy }: { userId: string | undefined; sortBy: SortKey }) {
  const { data, isLoading } = useQuery({
    queryKey: ["leaderboard", sortBy],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id,display_name,avatar_url,total_sushi,sushi,sps")
        .order(sortBy, { ascending: false })
        .limit(25);
      if (error) throw error;
      return data;
    },
    refetchInterval: 10000,
  });
  return isLoading ? (
    <p className="text-sm opacity-70">Loading…</p>
  ) : !data?.length ? (
    <p className="text-sm opacity-70">No chefs yet. Be the first!</p>
  ) : (
    <ol className="space-y-1">
      {data.map((r, i) => (
        <li
          key={r.id}
          className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm ${r.id === userId ? "bg-primary text-primary-foreground" : ""}`}
        >
          <span className={`w-6 font-display ${i < 3 ? "text-gold" : ""}`}>{i + 1}</span>
          <Avatar url={r.avatar_url} className="h-6 w-6" />
          <span className="flex-1 truncate font-bold">{r.display_name}</span>
          <span className="font-display">{fmt(r[sortBy])}{sortBy === "sps" ? "/s" : ""}</span>
        </li>
      ))}
    </ol>
  );
}
